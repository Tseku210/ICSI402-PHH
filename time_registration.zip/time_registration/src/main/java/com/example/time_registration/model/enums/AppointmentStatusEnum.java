package com.example.time_registration.model.enums;

// Цагын статусын төлөвүүд
public enum AppointmentStatusEnum {
    WAITING,
    DONE,
    CANCELLED,
    UNKNOWN,
}
