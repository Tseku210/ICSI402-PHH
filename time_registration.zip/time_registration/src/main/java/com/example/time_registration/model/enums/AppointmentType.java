package com.example.time_registration.model.enums;

// Цагийн төрөл
public enum AppointmentType {
    EXAMINATION,
    TREATMENT,
}
