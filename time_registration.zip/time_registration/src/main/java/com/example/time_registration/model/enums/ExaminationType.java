package com.example.time_registration.model.enums;

// Үзлэгийн төрөл
public enum ExaminationType {
    ANHAN,
    DAVTAN,
}
