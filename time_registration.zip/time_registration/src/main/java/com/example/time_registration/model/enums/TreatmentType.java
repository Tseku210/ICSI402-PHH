package com.example.time_registration.model.enums;

// Эмчилгээний төрөл
public enum TreatmentType {
    REHAB,
    DRUGS,
}
