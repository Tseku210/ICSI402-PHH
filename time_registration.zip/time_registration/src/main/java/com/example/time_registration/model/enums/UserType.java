package com.example.time_registration.model.enums;

// Хэрэглэгчийн төрөл
public enum UserType {
    DOCTOR,
    NURSE,
    PATIENT,
}
