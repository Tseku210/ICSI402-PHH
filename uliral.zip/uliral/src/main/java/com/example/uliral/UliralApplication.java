package com.example.uliral;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UliralApplication {

    public static void main(String[] args) {
        SpringApplication.run(UliralApplication.class, args);
    }

}
