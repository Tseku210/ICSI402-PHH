//package com.example.uliral.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.RequestMapping;
//
//@Controller
//@RequestMapping("/assignment")
//public class AssignmentController {
//    private final AssignmentService assignmentService;
//
//    @Autowired
//    public AssignmentController(AssignmentService assignmentService) {
//        this.assignmentService = assignmentService;
//    }
//
//}
