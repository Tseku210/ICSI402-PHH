//package com.example.uliral.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.RequestMapping;
//
//@Controller
//@RequestMapping("/internship")
//public class InternshipController {
//    private final InternshipService internshipService;
//
//    @Autowired
//    public InternshipController(InternshipService internshipService) {
//        this.internshipService = internshipService;
//    }
//
//}
