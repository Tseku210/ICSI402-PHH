package com.example.uliral.model.DAO;

public class AssignmentDao {
}
