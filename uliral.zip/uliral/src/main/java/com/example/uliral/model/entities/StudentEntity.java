package com.example.uliral.model.entities;

public interface StudentEntity {
}
