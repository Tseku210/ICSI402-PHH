package com.example.uliral.model.enums;

public enum StudentEntityType {
    STUDENT,
    DIPLOMA,
    INTERNSHIP,
    ASSIGNMENT,
    DOCUMENT
}

