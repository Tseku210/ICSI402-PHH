//package com.example.uliral.services;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//@Service
//public class InternshipService {
//
//    private final InternshipRepository internshipRepository;
//
//    @Autowired
//    public InternshipService(InternshipRepository internshipRepository) {
//        this.internshipRepository = internshipRepository;
//    }
//
//}
