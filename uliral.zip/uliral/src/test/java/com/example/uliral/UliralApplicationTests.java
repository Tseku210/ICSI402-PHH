package com.example.uliral;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UliralApplicationTests {

    @Test
    void contextLoads() {
    }

}
