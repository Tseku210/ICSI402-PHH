package com.example.web_dev_book.shared;

public enum AttributeType { CHECKED, SELECTED }

